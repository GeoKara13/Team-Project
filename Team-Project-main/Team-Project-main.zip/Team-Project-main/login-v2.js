const API = 'http://localhost:3000/api';

function showMessage(text, isError) {
  const box = document.getElementById('message-box');
  box.textContent = text;
  box.style.display = 'block';
  box.style.background = isError ? '#ffe0e0' : '#e0ffe0';
  box.style.color      = isError ? '#c00'    : '#060';
  box.style.border     = isError ? '1px solid #c00' : '1px solid #060';
}

// If already logged in, go straight to dashboard
if (localStorage.getItem('gda_token')) {
  window.location.href = 'dashboard-v2.html';
}

document.getElementById('login-form').addEventListener('submit', async function (e) {
  e.preventDefault();

  const email    = document.getElementById('login-email').value.trim();
  const password = document.getElementById('login-password').value;

  try {
    const response = await fetch(`${API}/auth/login`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ email, password })
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.error || 'Login failed.', true);
      return;
    }

    // Store JWT token and user info in localStorage
    localStorage.setItem('gda_token',    data.token);
    localStorage.setItem('gda_user',     JSON.stringify(data.user));
    localStorage.setItem('gda_username', data.user.fullname);

    showMessage(data.message + ' Redirecting...', false);
    setTimeout(() => { window.location.href = 'dashboard-v2.html'; }, 1000);

  } catch (err) {
    showMessage('Cannot connect to server. Make sure the backend is running.', true);
  }
});
