const API = 'http://localhost:3000/api';

// ─── Auth Guard ───────────────────────────────────────────────────────────────
const token = localStorage.getItem('gda_token');
const userName = localStorage.getItem('gda_username');

if (!token) {
  window.location.href = 'login-v2.html';
}

// Set welcome message
const welcomeEl = document.getElementById('welcome-message');
if (welcomeEl && userName) {
  welcomeEl.innerText = 'GDA Sports Shop - Welcome, ' + userName;
}

// ─── State ────────────────────────────────────────────────────────────────────
let allProducts    = [];   // all products fetched from DB
let filteredProducts = []; // currently shown products (after filter/sort)
let currentCategory = 'all';

// ─── Fetch & Render Products ─────────────────────────────────────────────────
async function loadProducts() {
  try {
    const res = await fetch(`${API}/products`);
    allProducts = await res.json();
    filteredProducts = [...allProducts];
    renderProducts(filteredProducts);
  } catch (err) {
    document.getElementById('productsContainer').innerHTML =
      '<div id="loading-msg">❌ Failed to load products. Is the server running?</div>';
  }
}

function renderProducts(products) {
  const container = document.getElementById('productsContainer');

  if (products.length === 0) {
    container.innerHTML = '<div id="loading-msg">No products found.</div>';
    return;
  }

  container.innerHTML = products.map(p => `
    <div class="product-card" data-category="${p.category}" data-price="${p.price}">
      <div class="image-box">
        <img src="${p.image}" alt="${p.name}" onerror="this.src='logo.png'">
      </div>
      <div class="brand-name">${p.brand}</div>
      <div class="product-title">${p.name}</div>
      <div class="price">€ ${p.price.toFixed(2)}</div>
      <button class="add-btn"    onclick="addToCart(${p.id}, '${escapeQuotes(p.name)}', ${p.price})">Add to Cart</button>
      <button class="remove-btn" onclick="removeFromCart(${p.id}, '${escapeQuotes(p.name)}')">Remove</button>
    </div>
  `).join('');
}

function escapeQuotes(str) {
  return str.replace(/'/g, "\\'").replace(/"/g, '&quot;');
}

// ─── Cart API Functions ───────────────────────────────────────────────────────
async function addToCart(productId, productName, price) {
  try {
    const res = await fetch(`${API}/cart/add`, {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + token
      },
      body: JSON.stringify({ product_id: productId, product_name: productName, price })
    });

    const data = await res.json();

    if (!res.ok) {
      if (res.status === 401 || res.status === 403) {
        alert('Session expired. Please log in again.');
        logout();
        return;
      }
      alert(data.error || 'Failed to add item.');
      return;
    }

    alert(productName + ' added to cart! ✅');
    loadCartCount();
  } catch (err) {
    alert('Cannot connect to server.');
  }
}

async function removeFromCart(productId, productName) {
  // Find the cart item by product name then remove it
  try {
    const res = await fetch(`${API}/cart`, {
      headers: { 'Authorization': 'Bearer ' + token }
    });
    const items = await res.json();
    const item = items.find(i => i.product_name === productName);

    if (!item) {
      alert('This item is not in your cart.');
      return;
    }

    const delRes = await fetch(`${API}/cart/remove/${item.id}`, {
      method:  'DELETE',
      headers: { 'Authorization': 'Bearer ' + token }
    });

    const data = await delRes.json();
    if (!delRes.ok) {
      alert(data.error || 'Failed to remove item.');
      return;
    }

    alert(productName + ' removed from cart.');
    loadCartCount();
  } catch (err) {
    alert('Cannot connect to server.');
  }
}

async function loadCartCount() {
  try {
    const res = await fetch(`${API}/cart`, {
      headers: { 'Authorization': 'Bearer ' + token }
    });
    if (!res.ok) return;
    const items = await res.json();
    const badge = document.getElementById('cart-count');
    if (badge) badge.innerText = items.length;
  } catch (err) {
    // silently ignore
  }
}

// ─── Filter & Sort ────────────────────────────────────────────────────────────
function filterCategory(category, clickedBtn) {
  currentCategory = category;

  document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
  if (clickedBtn) clickedBtn.classList.add('active');

  applyFilters();
}

function filterBySearch() {
  applyFilters();
}

function applyFilters() {
  const searchVal = document.getElementById('searchInput').value.toLowerCase();

  filteredProducts = allProducts.filter(p => {
    const matchCategory = currentCategory === 'all' || p.category === currentCategory;
    const matchSearch   = p.name.toLowerCase().includes(searchVal) ||
                          p.brand.toLowerCase().includes(searchVal);
    return matchCategory && matchSearch;
  });

  const sortVal = document.getElementById('sortSelect').value;
  applySortToFiltered(sortVal);
  renderProducts(filteredProducts);
}

function sortProducts() {
  const sortVal = document.getElementById('sortSelect').value;
  applySortToFiltered(sortVal);
  renderProducts(filteredProducts);
}

function applySortToFiltered(sortVal) {
  if (sortVal === 'low') {
    filteredProducts.sort((a, b) => a.price - b.price);
  } else if (sortVal === 'high') {
    filteredProducts.sort((a, b) => b.price - a.price);
  } else {
    // Default: restore original order from allProducts
    filteredProducts = allProducts.filter(p => {
      const matchCategory = currentCategory === 'all' || p.category === currentCategory;
      const searchVal = document.getElementById('searchInput').value.toLowerCase();
      const matchSearch = p.name.toLowerCase().includes(searchVal) ||
                          p.brand.toLowerCase().includes(searchVal);
      return matchCategory && matchSearch;
    });
  }
}

// ─── Logout ───────────────────────────────────────────────────────────────────
function logout() {
  localStorage.removeItem('gda_token');
  localStorage.removeItem('gda_user');
  localStorage.removeItem('gda_username');
  window.location.href = 'login-v2.html';
}

// ─── Initialize ───────────────────────────────────────────────────────────────
loadProducts();
loadCartCount();
