const API = 'http://localhost:3000/api';

function showMessage(text, isError) {
  const box = document.getElementById('message-box');
  box.textContent = text;
  box.style.display = 'block';
  box.style.background = isError ? '#ffe0e0' : '#e0ffe0';
  box.style.color      = isError ? '#c00'    : '#060';
  box.style.border     = isError ? '1px solid #c00' : '1px solid #060';
}

document.getElementById('register-form').addEventListener('submit', async function (e) {
  e.preventDefault();

  const fullname = document.getElementById('reg-fullname').value.trim();
  const email    = document.getElementById('reg-email').value.trim();
  const password = document.getElementById('reg-password').value;

  if (password.length < 8) {
    showMessage('Password must be at least 8 characters long!', true);
    return;
  }

  try {
    const response = await fetch(`${API}/auth/register`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body:    JSON.stringify({ fullname, email, password })
    });

    const data = await response.json();

    if (!response.ok) {
      showMessage(data.error || 'Registration failed.', true);
      return;
    }

    showMessage(data.message + ' Redirecting to login...', false);
    setTimeout(() => { window.location.href = 'login-v2.html'; }, 1500);

  } catch (err) {
    showMessage('Cannot connect to server. Make sure the backend is running.', true);
  }
});
