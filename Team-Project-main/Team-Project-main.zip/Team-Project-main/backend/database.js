/**
 * database.js  –  Pure-JS SQLite via sql.js (no native compilation required)
 *
 * Exports:
 *   db           – a compatibility shim that matches the better-sqlite3 API
 *                  (prepare / exec / transaction / pragma)
 *   initDatabase – async function that must be awaited before the server starts
 */

const initSqlJs = require('sql.js');
const fs   = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, 'gda.db');

// The actual sql.js Database instance (set by initDatabase)
let sqliteDb = null;
let _inTx    = false;   // true while inside a transaction

// ─── Persistence helper ──────────────────────────────────────────────────────
function saveToFile() {
  if (_inTx || !sqliteDb) return;          // don't flush mid-transaction
  const buf = sqliteDb.export();
  fs.writeFileSync(DB_PATH, Buffer.from(buf));
}

// ─── Low-level query helpers ─────────────────────────────────────────────────

/** Execute a SELECT and return every row as a plain object. */
function sqlAll(sql, params) {
  const stmt = sqliteDb.prepare(sql);
  if (params && params.length) stmt.bind(params);
  const rows = [];
  while (stmt.step()) rows.push(stmt.getAsObject());
  stmt.free();
  return rows;
}

/** Execute a SELECT and return the first row (or undefined). */
function sqlGet(sql, params) {
  const rows = sqlAll(sql, params);
  return rows.length ? rows[0] : undefined;
}

/** Execute an INSERT / UPDATE / DELETE; persist file; return { lastInsertRowid }. */
function sqlRun(sql, params) {
  sqliteDb.run(sql, params || []);
  const meta = sqlAll('SELECT last_insert_rowid() AS lastInsertRowid, changes() AS changes', []);
  saveToFile();
  return {
    lastInsertRowid: meta[0] ? meta[0].lastInsertRowid : 0,
    changes:         meta[0] ? meta[0].changes         : 0
  };
}

// ─── Argument normaliser ─────────────────────────────────────────────────────
// better-sqlite3 allows:  stmt.get(p1, p2)  or  stmt.get([p1, p2])
// Here we always end up with a flat array of positional parameters.
function normalise(args) {
  if (args.length === 0) return [];
  if (args.length === 1 && Array.isArray(args[0])) return args[0];
  return args;
}

// ─── better-sqlite3 compatibility shim ──────────────────────────────────────
const db = {

  /** Returns a statement object with .get() / .all() / .run() */
  prepare(sql) {
    return {
      get:  (...args) => sqlGet (sql, normalise(args)),
      all:  (...args) => sqlAll (sql, normalise(args)),
      run:  (...args) => sqlRun (sql, normalise(args)),
    };
  },

  /** Execute raw DDL (supports multiple semicolon-separated statements). */
  exec(sql) {
    sqliteDb.exec(sql);
    saveToFile();
  },

  /** Wrap a function in a BEGIN / COMMIT block; returns a callable wrapper. */
  transaction(fn) {
    return (...args) => {
      _inTx = true;
      sqliteDb.run('BEGIN');
      try {
        const result = fn(...args);
        sqliteDb.run('COMMIT');
        _inTx = false;
        saveToFile();
        return result;
      } catch (e) {
        sqliteDb.run('ROLLBACK');
        _inTx = false;
        throw e;
      }
    };
  },

  /** No-op: sql.js handles pragmas automatically via its WASM build. */
  pragma() {}
};

// ─── Database initialisation (called once at server startup) ─────────────────
async function initDatabase() {
  const SQL = await initSqlJs();

  // Load existing DB file or create a fresh one
  if (fs.existsSync(DB_PATH)) {
    sqliteDb = new SQL.Database(fs.readFileSync(DB_PATH));
  } else {
    sqliteDb = new SQL.Database();
  }

  // ── Create tables ──────────────────────────────────────────────────────────
  sqliteDb.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      fullname      TEXT    NOT NULL,
      email         TEXT    NOT NULL UNIQUE,
      password_hash TEXT    NOT NULL,
      created_at    TEXT    DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS products (
      id       INTEGER PRIMARY KEY AUTOINCREMENT,
      name     TEXT    NOT NULL,
      brand    TEXT    NOT NULL,
      category TEXT    NOT NULL,
      price    REAL    NOT NULL,
      image    TEXT    NOT NULL
    );

    CREATE TABLE IF NOT EXISTS cart_items (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id      INTEGER NOT NULL,
      product_id   INTEGER,
      product_name TEXT    NOT NULL,
      price        REAL    NOT NULL
    );

    CREATE TABLE IF NOT EXISTS orders (
      id             INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id        INTEGER NOT NULL,
      total          REAL    NOT NULL,
      payment_method TEXT    NOT NULL,
      created_at     TEXT    DEFAULT (datetime('now'))
    );

    CREATE TABLE IF NOT EXISTS order_items (
      id           INTEGER PRIMARY KEY AUTOINCREMENT,
      order_id     INTEGER NOT NULL,
      product_name TEXT    NOT NULL,
      price        REAL    NOT NULL
    );
  `);

  // ── Seed products (only once) ──────────────────────────────────────────────
  const count = sqlAll('SELECT COUNT(*) AS c FROM products', [])[0].c;

  if (count === 0) {
    const products = [
      ["NIKE Running Shoe 'REVOLUTION 8' in White",                         'Nike',          'shoes',    64.99, 'image 1.webp'],
      ["Men's Sneakers St Runner V4 Grey/White",                            'Puma',          'shoes',    40.00, 'image 2.webp'],
      ['Men\'s T-Shirt for Gym "The Gym"',                                  'Take Position', 'clothing', 19.99, 'image 3.jpeg'],
      ['Football Socks Blue',                                               'Givova',        'clothing',  8.00, 'image 4.webp'],
      ["England Home 2026 Stadium Men's Shirt",                             'Nike',          'clothing', 99.99, 'image 5.avif'],
      ["Nike Atletico Madrid FC 2025/26 3rd Home Men's Football Shirt",     'Nike',          'clothing', 75.00, 'image 6.webp'],
      ['Shirt Givova One',                                                  'Givova',        'clothing',  9.90, 'image 7.webp'],
      ["Men's Sneakers Anthracite - Nike V5 RNR",                          'Nike',          'shoes',    85.00, 'image 8.webp'],
      ['ADIDAS MILANO 23 SOCK ROY',                                        'Adidas',        'clothing',  8.00, 'image 9.webp'],
      ["ADIDAS PERFORMANCE Sports jersey 'FIGC TR JSY' in White",          'Adidas',        'clothing', 55.00, 'image 10.webp'],
    ];

    sqliteDb.run('BEGIN');
    for (const [name, brand, category, price, image] of products) {
      sqliteDb.run(
        'INSERT INTO products (name, brand, category, price, image) VALUES (?,?,?,?,?)',
        [name, brand, category, price, image]
      );
    }
    sqliteDb.run('COMMIT');
    console.log('✅  Database seeded with 10 products.');
  }

  saveToFile();
  console.log('✅  Database ready  →  ' + DB_PATH);
  return db;
}

module.exports = db;
module.exports.initDatabase = initDatabase;
