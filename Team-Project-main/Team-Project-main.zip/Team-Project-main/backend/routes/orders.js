const express = require('express');
const router  = express.Router();
const db      = require('../database');
const { verifyToken } = require('../middleware/auth');

// All order routes require authentication
router.use(verifyToken);

// ─── POST /api/orders ─────────────────────────────────────────────────────────
// Completes the order: saves order + items, then clears the cart
router.post('/', (req, res) => {
  const { payment_method } = req.body;

  if (!payment_method) {
    return res.status(400).json({ error: 'Payment method is required.' });
  }

  // Get user's cart
  const cartItems = db.prepare(
    'SELECT * FROM cart_items WHERE user_id = ?'
  ).all(req.user.id);

  if (cartItems.length === 0) {
    return res.status(400).json({ error: 'Your cart is empty.' });
  }

  // Calculate total
  const total = cartItems.reduce((sum, item) => sum + item.price, 0);

  // Save order and items in a single transaction
  const placeOrder = db.transaction(() => {
    const orderResult = db.prepare(
      'INSERT INTO orders (user_id, total, payment_method) VALUES (?, ?, ?)'
    ).run(req.user.id, total, payment_method);

    const orderId = orderResult.lastInsertRowid;

    const insertItem = db.prepare(
      'INSERT INTO order_items (order_id, product_name, price) VALUES (?, ?, ?)'
    );

    for (const item of cartItems) {
      insertItem.run(orderId, item.product_name, item.price);
    }

    // Clear cart after order placed
    db.prepare('DELETE FROM cart_items WHERE user_id = ?').run(req.user.id);

    return orderId;
  });

  const orderId = placeOrder();

  return res.status(201).json({
    message: `Order completed successfully via ${payment_method}! Thank you!`,
    orderId,
    total: total.toFixed(2)
  });
});

// ─── GET /api/orders ──────────────────────────────────────────────────────────
// Returns the authenticated user's full order history
router.get('/', (req, res) => {
  const orders = db.prepare(
    'SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC'
  ).all(req.user.id);

  // Attach items to each order
  const ordersWithItems = orders.map(order => {
    const items = db.prepare(
      'SELECT * FROM order_items WHERE order_id = ?'
    ).all(order.id);
    return { ...order, items };
  });

  return res.json(ordersWithItems);
});

// ─── GET /api/orders/:id ──────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const order = db.prepare(
    'SELECT * FROM orders WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.user.id);

  if (!order) return res.status(404).json({ error: 'Order not found.' });

  const items = db.prepare(
    'SELECT * FROM order_items WHERE order_id = ?'
  ).all(order.id);

  return res.json({ ...order, items });
});

module.exports = router;
