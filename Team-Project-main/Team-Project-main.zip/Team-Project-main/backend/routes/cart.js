const express = require('express');
const router  = express.Router();
const db      = require('../database');
const { verifyToken } = require('../middleware/auth');

// All cart routes require authentication
router.use(verifyToken);

// ─── GET /api/cart ────────────────────────────────────────────────────────────
router.get('/', (req, res) => {
  const items = db.prepare(
    'SELECT * FROM cart_items WHERE user_id = ?'
  ).all(req.user.id);

  return res.json(items);
});

// ─── POST /api/cart/add ───────────────────────────────────────────────────────
router.post('/add', (req, res) => {
  const { product_id, product_name, price } = req.body;

  if (!product_name || price === undefined) {
    return res.status(400).json({ error: 'product_name and price are required.' });
  }

  const result = db.prepare(
    'INSERT INTO cart_items (user_id, product_id, product_name, price) VALUES (?, ?, ?, ?)'
  ).run(req.user.id, product_id || null, product_name, price);

  return res.status(201).json({
    message: `${product_name} added to cart!`,
    cartItemId: result.lastInsertRowid
  });
});

// ─── DELETE /api/cart/remove/:id ─────────────────────────────────────────────
router.delete('/remove/:id', (req, res) => {
  const item = db.prepare(
    'SELECT * FROM cart_items WHERE id = ? AND user_id = ?'
  ).get(req.params.id, req.user.id);

  if (!item) {
    return res.status(404).json({ error: 'Cart item not found.' });
  }

  db.prepare('DELETE FROM cart_items WHERE id = ?').run(req.params.id);
  return res.json({ message: 'Item removed from cart.' });
});

// ─── DELETE /api/cart/clear ───────────────────────────────────────────────────
router.delete('/clear', (req, res) => {
  db.prepare('DELETE FROM cart_items WHERE user_id = ?').run(req.user.id);
  return res.json({ message: 'Cart cleared.' });
});

module.exports = router;
