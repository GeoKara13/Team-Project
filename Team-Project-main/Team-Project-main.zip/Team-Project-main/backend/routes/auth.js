const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const db      = require('../database');
const { JWT_SECRET } = require('../middleware/auth');

// ─── POST /api/auth/register ─────────────────────────────────────────────────
router.post('/register', (req, res) => {
  const { fullname, email, password } = req.body;

  // Basic validation
  if (!fullname || !email || !password) {
    return res.status(400).json({ error: 'All fields are required.' });
  }
  if (password.length < 8) {
    return res.status(400).json({ error: 'Password must be at least 8 characters.' });
  }

  // Check if email already exists
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    return res.status(409).json({ error: 'An account with this email already exists.' });
  }

  // Hash password and insert
  const password_hash = bcrypt.hashSync(password, 10);
  const result = db.prepare(
    'INSERT INTO users (fullname, email, password_hash) VALUES (?, ?, ?)'
  ).run(fullname, email, password_hash);

  return res.status(201).json({
    message: `Registration successful! Welcome, ${fullname}!`,
    userId: result.lastInsertRowid
  });
});

// ─── POST /api/auth/login ─────────────────────────────────────────────────────
router.post('/login', (req, res) => {
  const { email, password } = req.body;

  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password are required.' });
  }

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  const passwordMatch = bcrypt.compareSync(password, user.password_hash);
  if (!passwordMatch) {
    return res.status(401).json({ error: 'Invalid email or password.' });
  }

  // Sign JWT (expires in 24 hours)
  const token = jwt.sign(
    { id: user.id, email: user.email, fullname: user.fullname },
    JWT_SECRET,
    { expiresIn: '24h' }
  );

  return res.json({
    message: `Welcome back, ${user.fullname}!`,
    token,
    user: { id: user.id, fullname: user.fullname, email: user.email }
  });
});

// ─── GET /api/auth/me ─────────────────────────────────────────────────────────
const { verifyToken } = require('../middleware/auth');

router.get('/me', verifyToken, (req, res) => {
  const user = db.prepare('SELECT id, fullname, email, created_at FROM users WHERE id = ?').get(req.user.id);
  if (!user) return res.status(404).json({ error: 'User not found.' });
  return res.json(user);
});

module.exports = router;
