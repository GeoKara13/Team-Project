const express = require('express');
const router  = express.Router();
const db      = require('../database');

// ─── GET /api/products ───────────────────────────────────────────────────────
// Optional query param: ?category=shoes  or  ?category=clothing
router.get('/', (req, res) => {
  const { category } = req.query;

  let products;
  if (category && category !== 'all') {
    products = db.prepare('SELECT * FROM products WHERE category = ?').all(category);
  } else {
    products = db.prepare('SELECT * FROM products').all();
  }

  return res.json(products);
});

// ─── GET /api/products/:id ────────────────────────────────────────────────────
router.get('/:id', (req, res) => {
  const product = db.prepare('SELECT * FROM products WHERE id = ?').get(req.params.id);
  if (!product) return res.status(404).json({ error: 'Product not found.' });
  return res.json(product);
});

module.exports = router;
