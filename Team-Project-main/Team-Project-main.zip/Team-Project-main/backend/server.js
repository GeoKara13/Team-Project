const express = require('express');
const cors    = require('cors');
const path    = require('path');

const { initDatabase } = require('./database');

const app = express();

// ─── Middleware ───────────────────────────────────────────────────────────────
app.use(cors());
app.use(express.json());

// Serve all static frontend files (html, css, js, images) from project root
app.use(express.static(path.join(__dirname, '..')));

// ─── API Routes ───────────────────────────────────────────────────────────────
app.use('/api/auth',     require('./routes/auth'));
app.use('/api/products', require('./routes/products'));
app.use('/api/cart',     require('./routes/cart'));
app.use('/api/orders',   require('./routes/orders'));

// ─── Health Check ─────────────────────────────────────────────────────────────
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', message: 'GDA Sports API is running 🚀' });
});

// ─── Default route ────────────────────────────────────────────────────────────
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'register-v2.html'));
});

// ─── Async startup: init DB first, then listen ────────────────────────────────
const PORT = process.env.PORT || 3000;

async function startServer() {
  try {
    await initDatabase();

    app.listen(PORT, () => {
      console.log('');
      console.log('╔══════════════════════════════════════════════════╗');
      console.log('║          GDA Sports - Backend Server             ║');
      console.log('╠══════════════════════════════════════════════════╣');
      console.log(`║   Running at : http://localhost:${PORT}               ║`);
      console.log('║   Start here : http://localhost:3000/register-v2.html ║');
      console.log('╚══════════════════════════════════════════════════╝');
      console.log('');
    });
  } catch (err) {
    console.error('❌  Failed to start server:', err);
    process.exit(1);
  }
}

startServer();
