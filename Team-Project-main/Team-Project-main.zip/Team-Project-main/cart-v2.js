const API = 'http://localhost:3000/api';

// ─── Auth Guard ───────────────────────────────────────────────────────────────
const token = localStorage.getItem('gda_token');

if (!token) {
  window.location.href = 'login-v2.html';
}

// ─── Helpers ──────────────────────────────────────────────────────────────────
function showMsg(text, isError) {
  const box = document.getElementById('msg-box');
  box.textContent = text;
  box.style.display  = 'block';
  box.style.background = isError ? '#ffe0e0' : '#e0ffe0';
  box.style.color      = isError ? '#c00'    : '#060';
  box.style.border     = isError ? '1px solid #c00' : '1px solid #060';
}

// ─── Load Cart from Backend ───────────────────────────────────────────────────
async function loadCart() {
  const tableBody   = document.getElementById('cart-table-body');
  const totalDisplay = document.getElementById('cart-total-price');

  try {
    const res = await fetch(`${API}/cart`, {
      headers: { 'Authorization': 'Bearer ' + token }
    });

    if (res.status === 401 || res.status === 403) {
      showMsg('Session expired. Please log in again.', true);
      setTimeout(() => { window.location.href = 'login-v2.html'; }, 1500);
      return;
    }

    const items = await res.json();
    tableBody.innerHTML = '';
    let total = 0;

    if (items.length === 0) {
      tableBody.innerHTML = "<tr><td colspan='3' style='text-align:center;'>Your cart is empty.</td></tr>";
      totalDisplay.innerText = '€ 0.00';
      return;
    }

    items.forEach(item => {
      total += item.price;
      const row = `<tr>
        <td>${item.product_name}</td>
        <td>€ ${item.price.toFixed(2)}</td>
        <td><button class="delete-btn" onclick="removeItem(${item.id})">Delete ❌</button></td>
      </tr>`;
      tableBody.innerHTML += row;
    });

    totalDisplay.innerText = `€ ${total.toFixed(2)}`;

  } catch (err) {
    showMsg('Cannot connect to server. Make sure the backend is running.', true);
  }
}

// ─── Remove Single Item ───────────────────────────────────────────────────────
async function removeItem(cartItemId) {
  try {
    const res = await fetch(`${API}/cart/remove/${cartItemId}`, {
      method:  'DELETE',
      headers: { 'Authorization': 'Bearer ' + token }
    });

    const data = await res.json();
    if (!res.ok) {
      showMsg(data.error || 'Failed to remove item.', true);
      return;
    }

    loadCart(); // refresh table
  } catch (err) {
    showMsg('Cannot connect to server.', true);
  }
}

// ─── Complete Order ───────────────────────────────────────────────────────────
async function completeOrder() {
  const payment_method = document.querySelector('input[name="payment"]:checked').value;

  try {
    const res = await fetch(`${API}/orders`, {
      method:  'POST',
      headers: {
        'Content-Type':  'application/json',
        'Authorization': 'Bearer ' + token
      },
      body: JSON.stringify({ payment_method })
    });

    const data = await res.json();

    if (!res.ok) {
      showMsg(data.error || 'Order failed.', true);
      return;
    }

    showMsg(`✅ ${data.message}  |  Order #${data.orderId}  |  Total: € ${data.total}`, false);

    // Refresh the cart display (now empty)
    setTimeout(() => {
      loadCart();
      window.location.href = 'dashboard-v2.html';
    }, 2500);

  } catch (err) {
    showMsg('Cannot connect to server.', true);
  }
}

// ─── Initialize ───────────────────────────────────────────────────────────────
loadCart();
